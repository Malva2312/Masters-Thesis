Protocol number: 1
Who created it: Eduardo de Matos Rodrigues
Which center is the creator associated with: CTM
Which group is the creator associated with": VCMI
When was it created: 2025-03-20
What was created: 2D Lung nodule bounding boxes
Why was it created: To be used by Afonso Abreu in his master's project
